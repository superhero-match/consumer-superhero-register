create
    definer = root@localhost procedure delete_superhero(IN id varchar(255), IN deleted_at varchar(255))
BEGIN

UPDATE superhero 
SET 
	sueprhero.deleted_at = deleted_at,
	superhero.is_deleted = 1
WHERE superhero.id = id;

END;

