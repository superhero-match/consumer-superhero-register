create
    definer = root@localhost procedure insert_new_profile_picture(IN superhero_id varchar(255),
                                                                  IN profile_pic_url varchar(255), IN position int,
                                                                  IN created_at varchar(255),
                                                                  IN updated_at varchar(255),
                                                                  IN deleted_at varchar(255))
BEGIN

INSERT INTO profile_picture (
	profile_picture.superhero_id,
    profile_picture.profile_pic_url,
    profile_picture.position,
    profile_picture.created_at,
    profile_picture.updated_at,
    profile_picture.deleted_at
	)
	VALUES (
	superhero_id,
	profile_pic_url,
    position,
    created_at,
    updated_at,
    deleted_at
    );

END;

